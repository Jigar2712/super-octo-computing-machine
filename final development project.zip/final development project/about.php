<!DOCTYPE html>
<html>
<head>
<title>
About
</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
       
        $("#div2").fadeIn("slow");
       
    });
});
</script>
<style>
	body{
				background-color:black;
			}
			h1{
				margin-top: 200px;
				color:	#493636; 
				font-size: 50px;
				text-align: center;
		}
			p{
				text-align:justify;
				color:white;
				font-size:28px;
		}

</style>

</head>
<body>


<div  style = "border: 1px solid black; width:100%; height:900px; background-image: url(wood1.jpg)">
<button style="margin-left:50%;">Click to show about</button><br><br>


<div id="div2" style="width:80px;height:80px;display:none;margin-left:30%;
				margin-top:90px;
				border:1px; 
				width:800px; 
				height:700px;"><h1 style = "color:white">About</h1>
<p>
Hello visitor, myself Jigar Parmar currently pursuing Master in Information Systems Management at Marist college, Poughkeepsie, NY, 12601. Before that I was working
as data analyst in a local company known as VC-erp located in Ahmedabad, Gujarat, India. I have in total of 18 months of experience in this field. Seeking summer internship
opportunity which will help me in shaping my bright future. I am self motivated, eager to learn new things, team player, sometimes motivator. My skill sets include Eclipse, 
SQL developer, SQL data modeler, MS Power point, MS Excel, MS Word, MS VISIO,Tableau
</p> 
</div>
</div>

</body>
</html>
