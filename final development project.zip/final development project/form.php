<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body style = "background-color:white;">  

<?php
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

?>

<?php
// connecting to mysql
$link= mysqli_connect("localhost","root","","jigchu");
// Check connection
//if (!$link) {
//    die("Connection failed: " . mysqli_connect_error());
//}
//echo "Connected successfully";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["website"])) {
    $website = "";
  } else {
    $website = test_input($_POST["website"]);
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["comment"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
  
  date_default_timezone_set("America/New_York");
       $timestamp = date('Y-m-d G:i:s');

$querry = "INSERT INTO contact (name,email,website,comment,gender,time_stamp)
VALUES ('$name', '$email', '$website', '$comment', '$gender' , '$timestamp')";

if ($link->query($querry) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $querry . "<br>" . $link->error;
}

  
  
  // Mail Stuff
       $to = "jigar.parmar92@gmail.com";
       $subject = "New Form Submitted";
       $txt = "Someone submitted new form";
       $headers = "From: donotreply@fmt.com" ;
	   
	   $stmt=$link->prepare($querry);
                    if($stmt->execute()==true)
                        {
                             mail($to,$subject,$txt,$headers);
                             echo "<script>alert(' Submitted Successful')</script>";
                             EXIT();
                             //header('Location:index.php');
                        }
  
  
}

// triming any backslash or white space
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}





?>

<div  style = "border: 1px solid black; width:100%; height:955px; background-image: url(wood1.jpg)">
<div style = "margin-left: 45%">
<h2 style = "color:white">Message me</h2>
<p><span class="error">* required field.</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <h3 style = "color:white">Name:</h3> <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  <h3 style = "color:white">E-mail:</h3> <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  <h3 style = "color:white">Website:</h3> <input type="text" name="website">
  <span class="error"><?php echo $websiteErr;?></span>
  <br><br>
 <h3 style = "color:white"> Comment: </h3> <textarea name="comment" rows="5" cols="40"></textarea>
  <br><br>
  <h3 style = "color:white">Gender:</h3>
  <input type="radio" name="gender" value="female"><h3 style = "color:white">Female</h3>
  <input type="radio" name="gender" value="male"><h3 style = "color:white">Male</h3>
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form></div>
</div>




<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $website;
echo "<br>";
echo $comment;
echo "<br>";
echo $gender;
echo "<br>";
//echo $time_stamp;
?>

</body>
</html>